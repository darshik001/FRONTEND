---
title: Building check
categories:
  - Buildings
tags:
  - company
  - enterprise
  - organization
  - office
  - business
added: 1.10.0
---
