---
title: Ban
categories:
  - Real World
tags:
  - no
  - "not allowed"
  - block
added: 1.11.0
---
