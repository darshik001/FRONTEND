---
title: Broadcast pin
categories:
  - Communications
tags:
  - radio
  - "radio wave"
  - amplify
  - wavelength
  - podcast
---
